#pragma once

#include "config.h"

class Motor
{
public:
    Motor();
    ~Motor() = default;
    Motor(const Motor&) = delete;

    bool turn_rotor() const;
    void forward_test_value(const std::string& value);

private:

    Config m_settings;

};
