#pragma once

#include <map>
#include <string>

class Config
{
public:
    explicit Config(bool in_testing=false);
    ~Config() = default;
    Config(const Config&) = delete;

    int get_setting_int(const std::string& key) const;
    std::string get_setting_string(const std::string& key) const;
    void set_test_value(const std::string& value);

private:
    std::map<std::string, std::string> m_settings;
    bool m_in_testing;
    std::string m_test_value;
};
