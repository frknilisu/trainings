#include "motor.h"

#include <iostream>

#ifdef _TESTING
const bool in_testing = true;
#else
const bool in_testing = false;
#endif


Motor::Motor() :
   m_settings(in_testing)
{
    std::cout << "I'm a motor!" << std::endl;
}

bool Motor::turn_rotor() const
{

    int value = m_settings.get_setting_int("motor_speed");

    std::cout << "Start turing at " << value << " speed" << std::endl;

    return true;
}

void Motor::forward_test_value(const std::string &value)
{
    m_settings.set_test_value(value);
}
